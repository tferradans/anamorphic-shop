Pick your focus gear based on the look of your Jupiter 9. Each Jupiter 9 STL matches to the lens image.

V1 is for the older Jupiter 9's, with the finger indents on the focus ring, V2 is for the newer versions, with the round focus ring.