AnaDistort.ffx v1.0
by Tito Ferradans

AnaDistort.ffx is an After Effects preset that allows for accurate control in creating custom anamorphic lens distortion.

1. INSTALL

You can paste the file at the folders below so it loads up with After Effects. If the folder does not exist, simply create it in the path below.

(Windows) My Documents/Adobe/After Effects <vesion>/User Presets/
(Mac OS) Documents/Adobe/After Effects <vesion>/User Presets/

Once the preset is installed you can find it in the "Effects and Presets" list.

2. HOW TO USE

Import your footage into a Composition that has your desired aspect ratio. Do not crop your footage in advance. The ideal scenario is bringing in 16:9 footage into a Cinemascope composition so we can rescue some of the lost top and bottom of the shot through the distortion.

Go to the "Scale" parameter of your footage and Alt + click the stopwatch to apply the following expression:

var w = (thisComp.width/width)*100;
var h = (thisComp.height/height)*100;

[w,h]

This will resize your footage to the Comp size. It will only look strange for a moment. As soon as you apply AnaDistort in the next step, the footage goes back to looking normal.

Create an Adjustment Layer over the footage you want to distort. Search for "AnaDistort" in the "Effects and Presets" tab and drag it over the Adjustment Layer to apply it. On the "Effect Controls" tab you will now have a list of selectors.

!!! DO NOT CHANGE ANY OF THE RED PARAMETERS !!!

"DISTORT" is a layer selector. Pick your footage layer from the dropdown menu. This will tell AnaDistort the dimensions of your layer, instead of just using the Composition's size.

"WIDTH" and "HEIGHT" are internal controls. You should ignore them.

"CORNERS" controls the distortion by moving all corners in sync. Positive values will give you barrel distortion, negative values create pincushion. 0 gives you no distortion.

"HORIZONTAL TANGENTS" controls stretching on the center and corners of the frame. Older anamorphics are famous for "mumps", which is when the center of the shot looks more stretched than it should. Positive values will compress the center and stretch the sides, negative values do the opposite (creating "mumps").

"VERTICAL TANGENTS" has the same effect but on the vertical axis.

"MAKE IT BENDY" pushes a few more control points around, creating a more intense distortion from the same slider values. It only works for barrel distortion and it will auto-disable if "CORNERS" is pushed below 0.

"Bezier Warp" is the core of the distortion and is rigged to multiple expressions. Do not touch anything!

--

This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License.
http://creativecommons.org/licenses/by-sa/4.0/
