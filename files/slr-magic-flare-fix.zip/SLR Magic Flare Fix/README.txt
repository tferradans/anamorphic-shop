SLR Magic Flare Fix v1.0
by Tito Ferradans

Through the use of specific hue selections, these presets help you tweak the look of flares from SLR Magic's Anamorphic adapters.

AFTER EFFECTS
Place the "SLR Magic Flare Fix.ffx" file at:
Windows - "C:/Program Files/Adobe/After Effects <version>/Support Files/Plug-ins" or "/Presets"
OSX - "Applications/Adobe After Effects <version>/Plugins" or "/Presets"

Channel Control - I'm starting from the Blue channel. Keep this as it is.
Channel Range - Controls which hues are affected. The default is the blue hue, and you can fine tune from there.
Blue Hue - Affects the hue of the flare, and you can rotate it for creative effects.
Blue Saturation - I recommend toning this down to make the flare more subtle.
Blue Lightness - Be careful as this setting can easily look odd. Tweak the values up or down just a little for better blending the new flare with the footage.

PREMIERE
Launch Premiere Pro. Go into the "Effects" tab and select "Import Presets". Navigate to the "SLR Magic Flare Fix.prfpset" file and select it.

Every setting of the Lumetri Color is disabled but HSL Secondary.
Use the H, S and L sliders to define which hues are affected. As you drag them around, a matte will show up. The white part is your current selection. The goal is to get the entire flare and nothing else.

Correction - The color wheel and slider will affect the look of the flare. Small adjustments will achieve the best results.
Temperature - Negative values add blue, positive values add yellow. Tweak until you're happy with the results. Default is 25.
Tint - Negative values add green, positive adds magenta. Tweak until you're happy with the results. Default is 0.
Contrast - I wouldn't change it. Default is 0.
Sharpen - I wouldn't change it. Default is 0.
Saturation - Values above 100 increase saturation, below 100 decrease saturation of the flare. Default is 35.

---

This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License.
http://creativecommons.org/licenses/by-sa/4.0/