1. NAMING

Each file is named <aspect ratio>-<lens>.

The first part is the aspect ratio the cropmark frames, named after the anamorphic stretch that gives it on a 16:9 sensor:
133x is 2.35:1 (what a 1.33x lens gives).
15x is 2.66:1 (what a 1.5x lens gives).
2x is 3.56:1 (what a 2x lens gives).

The second part is the lens on your camera:
norm is a regular, spherical lens.
133x, 15x and 2x are anamorphic lenses with that stretch.

Examples:
133x-norm frames 2.35:1 with a spherical lens.
133x-2x frames 2.35:1 while you shoot with a 2x anamorphic.
2x-133x frames 3.56:1 while you shoot with a 1.33x anamorphic.

2. INSTALL

To install these cropmarks, make sure your Canon camera has Magic Lantern installed.
Copy the BMP files to the ML/CROPMKS folder in your card.

3. ADDITIONAL INFORMATION

This link is a video tutorial on how to make your own cropmarks, if you want to add specific functionalities.
https://www.youtube.com/watch?v=rbbeZ9anQPA

More information about Magic Lantern at http://www.magiclantern.fm

--

This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License.
http://creativecommons.org/licenses/by-sa/4.0/
