Anamorphic Mumps Corrector v1.0
by Tito Ferradans and Lucas Pfaff

Using a combination of native effects and expressions, AMC helps lessening anamorphic mumps and distortion. Apply it to an Adjustment Layer or directly to the footage and adjust intensity with the sliders.

AMOUNT
Ranges from -50 to 100. Controls how much compression is applied. Positive values will compress the middle area, negative values will compress the edges.

CURVATURE
Ranges from -100 to 100. Controls barrel and pincushion distortions. Negative values apply barrel distortion, positive values apply pincushion distortion. Can be used to simulate these distortions on undistorted footage, or to lessen anamorphic character. Set to zero for none.

CURVATURE_CTRL
Ranges from 1 to 30. Controls the intensity of the distortion. Lower values will create more extreme warps, higher values lessen the effect.

WARP (do not change)
Bezier warp rigged with expressions connected to the controllers. Will fit any comp size automatically. Do not change the values or disable the expressions or the effect will stop working.

CTRL (do not change)
Proxy to make values relative to comp size for AMOUNT and CURVATURE sliders before passing them to WARP. Do not change the values or disable the expressions or the effect will stop working.

---

This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License.
http://creativecommons.org/licenses/by-sa/4.0/