﻿myComp = app.project.activeItem;

//used to re-center the layers, no matter the comp size.
var reCenter = "var x = thisComp.width/2;" + "\r" +
                        "var y = thisComp.height/2;" + "\r" +
                        "[x,y]";
                        
var reScale = "var w = 100;" + "\r" +
                      "var h = 100;" + "\r" +
                      "if (thisComp.width != width) {" + "\r" +
                        "var rescale = thisComp.width/width;" + "\r" +
                        "w = w*rescale;" + "\r" +
                        "h = h*rescale; };" + "\r" +
                      "[w,h];";
                      
 var aspectRatio =  "var w = 100;" + "\r" +
                              "var h = 100;" + "\r" +
                              "var newH = width/effect('AspectRatio ctrl')('Slider');" + "\r" +
                              "var newScale = newH/height*100;" + "\r" +
                              "h = newScale;" + "\r" +
                              "if (thisComp.width != width) {" + "\r" +
                              "var rescale = thisComp.width/width;" + "\r" +
                              "w = w*rescale;" + "\r" +
                              "h = h*rescale;};" + "\r" +
                              "[w,h];";


// creates AR Mask
var myMask = myComp.layers.addSolid([0,0,0], "AR_MASK", 1920, 1080, 1, myComp.duration);

// insert expressions for reCenter and reScale
myMask.property("position").expression = reCenter;
myMask.property("scale").expression= reScale;

// creates AR Alpha
var myAlpha = myComp.layers.addSolid([0,0,0], "AR_MASK_ALPHA", 1920, 1080, 1, myComp.duration);

//add slider control, rename it and set base to 2.4:1
mySlider = myAlpha.property("ADBE Effect Parade").addProperty("ADBE Slider Control");
myAlpha.property("ADBE Effect Parade").property("ADBE Slider Control").name = "AspectRatio ctrl";
myAlpha.property("ADBE Effect Parade").property("ADBE Slider Control").property("Slider").setValue(2.4);

// insert expressions for reCenter and reScale
myAlpha.property("position").expression = reCenter;
myAlpha.property("scale").expression= aspectRatio;

//set MASK to Alpha Inverted
myMask.trackMatteType = TrackMatteType.ALPHA_INVERTED;

