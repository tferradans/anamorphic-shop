autoMask.jsx v1.0
by Tito Ferradans

autoMask.jsx is an After Effects script that creates a couple black solids to deliver the desired aspect ratio for your Composition.

1. INSTALL

You can paste the file at the folders below so it loads up with After Effects or you can simply navigate to the file location whenever you want to use it.

(Windows) Program Files\Adobe\Adobe After Effects <version>\Support Files\Scripts
(Mac OS) Applications/Adobe After Effects <version>\Scripts

To run a loaded script, choose File > Scripts > [script name]
To run a script that has not been loaded, choose File > Scripts > Run Script File, locate and select a script, and click Open.

2. HOW TO USE

Once you have your composition set up, just hit autoMask and that creates two black solid layers (AR_MASK and AR_MASK_ALPHA). They interact with one another in order to create the desired aspect ratio.

The default setting is 2.4:1. You can change that number by altering the "AspectRatio ctrl" slider in the AR_MASK_ALPHA effects. 
Use only values above 1.0. Standard values are 2.35, 2.4, 2.66, 3.56.

Both layers are locked to center and auto-scalable, allowing you to change your Composition size freely.

--

This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License.
http://creativecommons.org/licenses/by-sa/4.0/
